#include<bits/stdc++.h>
using namespace std;

int main() {
    ifstream file("input.csv");

    string line, word;
    string Level,Routine,PlayGame,Class;

    map<string, int> class1;
    map<string, map<string, int>> class2;

    if(!file.is_open()) {
        perror("Couldn't open the file:");
        return -1;
    }

    int i=0;
    string subClass;

    while(getline(file, line)) {
        stringstream str(line);
        getline(str, Level, ',');
        getline(str, Routine, ',');
        getline(str, PlayGame, ',');
        getline(str, Class, ',');
      

        int column;
        if(i == 0) {
            i++;
            cout<<"Enter sub class column:";
            cin>>column;
            continue;
        }

        if(column == 1) {
            subClass = Level;
        }
        else if(column == 2) {
            subClass = Routine;
        }
        else if(column == 3) {
            subClass = PlayGame;
        }
        
        class1[Class]++;
        class2[subClass][Class]++;
    }

    double pos = class1["True"], neg = class1["False"];
    double total = pos+neg;

    double class1_entropy = -((pos/total) * log2(pos/total) + (neg/total) * log2(neg/total));
    cout<<"Class1 Entropy:"<<class1_entropy<<endl;

    double class2_entropy = 0;
    for(auto itr:class2) {
        string d_class = itr.first;
        double pos1 = class2[d_class]["True"], neg1 = class2[d_class]["False"];

        double total1 = pos1+neg1;

        class2_entropy += -((pos/total)*((pos1/total1) * log2(pos1/total1)) + (neg/total)*((neg1/total1) * log2(neg1/total1)));
    }

    cout<<"Class2 Entropy:"<<class2_entropy<<endl;
    cout<<"Info Gain:"<<class1_entropy-class2_entropy<<endl;

    return 0;
}